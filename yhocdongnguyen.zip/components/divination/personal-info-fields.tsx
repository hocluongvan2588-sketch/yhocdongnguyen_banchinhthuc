"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

interface PersonalInfoFieldsProps {
  gender: string
  setGender: (value: string) => void
  birthYear: string
  setBirthYear: (value: string) => void
  birthMonth: string
  setBirthMonth: (value: string) => void
  birthDay: string
  setBirthDay: (value: string) => void
  painLocation: string
  setPainLocation: (value: string) => void
  userLocation: string
  setUserLocation: (value: string) => void
}

export function PersonalInfoFields({
  gender,
  setGender,
  birthYear,
  setBirthYear,
  birthMonth,
  setBirthMonth,
  birthDay,
  setBirthDay,
  painLocation,
  setPainLocation,
  userLocation,
  setUserLocation,
}: PersonalInfoFieldsProps) {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label className="text-sm">Giới tính</Label>
        <Select value={gender} onValueChange={setGender}>
          <SelectTrigger>
            <SelectValue placeholder="Chọn giới tính" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="male">Nam</SelectItem>
            <SelectItem value="female">Nữ</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label className="text-sm flex items-center gap-2">
          Ngày sinh (Dương lịch)
          <Badge variant="outline" className="text-[10px]">
            Tự động chuyển sang Can Chi
          </Badge>
        </Label>
        <div className="grid grid-cols-3 gap-2">
          <Input
            type="number"
            min="1900"
            max="2100"
            value={birthYear}
            onChange={(e) => setBirthYear(e.target.value)}
            placeholder="Năm"
          />
          <Input
            type="number"
            min="1"
            max="12"
            value={birthMonth}
            onChange={(e) => setBirthMonth(e.target.value)}
            placeholder="Tháng"
          />
          <Input
            type="number"
            min="1"
            max="31"
            value={birthDay}
            onChange={(e) => setBirthDay(e.target.value)}
            placeholder="Ngày"
          />
        </div>
        <p className="text-xs text-muted-foreground">
          Hệ thống tự tính Can Chi Năm, Can Chi Ngày và Cung Phi cho phân tích chính xác
        </p>
      </div>

      <div className="space-y-2">
        <Label className="text-sm">Vị trí đau/khó chịu (nếu có)</Label>
        <Input
          type="text"
          value={painLocation}
          onChange={(e) => setPainLocation(e.target.value)}
          placeholder="VD: Đau đầu, đau lưng..."
        />
      </div>

      <div className="space-y-2">
        <Label className="text-sm">Tỉnh/Thành phố hiện tại</Label>
        <Input
          type="text"
          value={userLocation}
          onChange={(e) => setUserLocation(e.target.value)}
          placeholder="VD: Hà Nội, TP.HCM..."
        />
      </div>
    </div>
  )
}
